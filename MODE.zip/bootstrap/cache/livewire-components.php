<?php return array (
  'licitaciones' => 'App\\Http\\Livewire\\Licitaciones',
  'licitaciones-crear' => 'App\\Http\\Livewire\\LicitacionesCrear',
  'user' => 'App\\Http\\Livewire\\User',
);