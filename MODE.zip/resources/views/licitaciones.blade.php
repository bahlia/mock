@extends('layouts.app')

@section('content')
    @livewire('licitaciones')
@endsection