<div>
    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#home">Realizadas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#menu1">Recibidas</a>
        </li>
      </ul>
      
      <!-- Tab panes -->
      <div class="tab-content">
        <div class="tab-pane active" id="home">
            <button type="button" class="btn btn-primary">CREAR LICITACION</button>
            @foreach ($tenders as $t)
            <div class="card">
                <div class="card-body">
                    <h2>{{ $t["title"] }}</h2>
                    <b>{{ $t["company"] }}</b>
                    <p> {{ $t["description"] }} </p>
                    <p>
                       <h4> <span class="badge bg-primary"><b>De</b> {{ $t["from"] }} </span></h4><h4> <span class="badge bg-primary"> <b>Hasta</b> {{ $t["to"] }} </span></h4>
                        <h1 class="mt-3"> <b> {{ $t["value"] }} </b> </h1>
                    </p>
                </div>
              </div>
            @endforeach
            
        </div>
        <div class="tab-pane fade" id="menu1">mundo</div>
      </div>
</div>
