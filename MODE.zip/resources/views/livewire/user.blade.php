<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-9">
            <h1>Panel empresa</h1>
        </div>  
        <div class="col-sm-4 col-md-6">
        
            <div class="form-floating mb-3">              
                <input type="text"  class="form-control" id="floatingInput" wire:model="name">
                <label for="floatingInput">Nombre</label>
            </div>

            <div class="form-floating mb-3">              
                <input type="text"  class="form-control" id="floatingInput" wire:model="name">
                <label for="floatingInput">Description</label>
            </div>


            <div class="form-floating mb-3">
                <select class="form-select" id="floatingSelect" aria-label="Floating label select example" wire:model="myCategories">
                    @foreach ($categories as $c)
                        <option value="{{ $c }}">{{ $c }}
                        </option>
                    @endforeach
                </select>     
                <label for="floatingInput">Categorias</label>
            </div>

            <button class="btn btn-primary" type="button" wire:click="updateCategories">save categories</button>
        </div>  

        <div class="col-sm-4 col-md-6">
            <div class="justify-content-center">
                <h1>Tags</h1>
            </div> 
            <ul class="list-unstyled">
                @foreach ($user["tags"] as $t)
                <button class="btn btn-success" type="button" wire:click="removeTag({{$loop->index}})"> {{ $t }} X</button>
                @endforeach
            </ul>
            
            <div class="input-group input-group-sm mb-3">              
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" wire:model="newTag">
            </div>
            
            <button class="btn btn-primary" type="button" wire:click="addTag">add tag</button>

        </div>
    </div>
</div>