<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        session(["user" => [
            "name" => "Bahimer Corp",
            "description" => "SOFTWARE DEVELOPERS",
            "categories" => [
                "software",
                "Seguridad"
            ],
            "tags" => [
                "make",
                "build",
                "deploy",
                "security"
            ],
            "tenders" => []
        ]]);

        session([
            "categories" => [
                "software",
                "IA",
                "Admin",
                "Seguridad",
                "API REST"
            ]
        ]);

        session([
            "tenders" => []
        ]);

        return redirect("/panel");
        return view('home');
    }
}
