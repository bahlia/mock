<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Licitaciones extends Component
{

    public $tenders;

    public function mount(){
        $this->tenders = session("tenders");
    }

    public function render()
    {
        return view('livewire.licitaciones');
    }
}
