<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user')->html();
} elseif ($_instance->childHasBeenRendered('zYz6Hgw')) {
    $componentId = $_instance->getRenderedChildComponentId('zYz6Hgw');
    $componentTag = $_instance->getRenderedChildComponentTagName('zYz6Hgw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zYz6Hgw');
} else {
    $response = \Livewire\Livewire::mount('user');
    $html = $response->html();
    $_instance->logRenderedChild('zYz6Hgw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/erick/Escritorio/ModeloDeNegocios/localizador_inteligente_de_oportunidades_de_negocio_frontend/modeloDeNegocios/resources/views/panel.blade.php ENDPATH**/ ?>