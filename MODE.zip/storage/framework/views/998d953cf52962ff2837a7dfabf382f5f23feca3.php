<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('licitaciones')->html();
} elseif ($_instance->childHasBeenRendered('h4BV5m7')) {
    $componentId = $_instance->getRenderedChildComponentId('h4BV5m7');
    $componentTag = $_instance->getRenderedChildComponentTagName('h4BV5m7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h4BV5m7');
} else {
    $response = \Livewire\Livewire::mount('licitaciones');
    $html = $response->html();
    $_instance->logRenderedChild('h4BV5m7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shelby/Work/Demos/Mock/resources/views/licitaciones.blade.php ENDPATH**/ ?>