<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-9">
            <h1>Panel empresa</h1>
        </div>  
        <div class="col-sm-4 col-md-6">
        
            <div class="form-floating mb-3">              
                <input type="text"  class="form-control" id="floatingInput" wire:model="name">
                <label for="floatingInput">Nombre</label>
            </div>

            <div class="form-floating mb-3">              
                <input type="text"  class="form-control" id="floatingInput" wire:model="name">
                <label for="floatingInput">Description</label>
            </div>


            <div class="form-floating mb-3">
                <select class="form-select" id="floatingSelect" aria-label="Floating label select example" wire:model="myCategories">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c); ?>"><?php echo e($c); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>     
                <label for="floatingInput">Categorias</label>
            </div>

            <button class="btn btn-primary" type="button" wire:click="updateCategories">save categories</button>
        </div>  

        <div class="col-sm-4 col-md-6">
            <div class="justify-content-center">
                <h1>Tags</h1>
            </div> 
            <ul class="list-unstyled">
                <?php $__currentLoopData = $user["tags"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="btn btn-success" type="button" wire:click="removeTag(<?php echo e($loop->index); ?>)"> <?php echo e($t); ?> X</button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
            <div class="input-group input-group-sm mb-3">              
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" wire:model="newTag">
            </div>
            
            <button class="btn btn-primary" type="button" wire:click="addTag">add tag</button>

        </div>
    </div>
</div><?php /**PATH /home/erick/Escritorio/ModeloDeNegocios/localizador_inteligente_de_oportunidades_de_negocio_frontend/modeloDeNegocios/resources/views/livewire/user.blade.php ENDPATH**/ ?>