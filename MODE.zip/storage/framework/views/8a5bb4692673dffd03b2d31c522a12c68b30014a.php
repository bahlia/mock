<div>
    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#home">Realizadas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#menu1">Recibidas</a>
        </li>
      </ul>
      
      <!-- Tab panes -->
      <div class="tab-content">
        <div class="tab-pane active" id="home">
            <button type="button" class="btn btn-primary">CREAR LICITACION</button>
            <?php $__currentLoopData = $tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <h2><?php echo e($t["title"]); ?></h2>
                    <b><?php echo e($t["company"]); ?></b>
                    <p> <?php echo e($t["description"]); ?> </p>
                    <p>
                       <h4> <span class="badge bg-primary"><b>De</b> <?php echo e($t["from"]); ?> </span></h4><h4> <span class="badge bg-primary"> <b>Hasta</b> <?php echo e($t["to"]); ?> </span></h4>
                        <h1 class="mt-3"> <b> <?php echo e($t["value"]); ?> </b> </h1>
                    </p>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <div class="tab-pane fade" id="menu1">mundo</div>
      </div>
</div>
<?php /**PATH /home/erick/Escritorio/ModeloDeNegocios/localizador_inteligente_de_oportunidades_de_negocio_frontend/modeloDeNegocios/resources/views/livewire/licitaciones.blade.php ENDPATH**/ ?>