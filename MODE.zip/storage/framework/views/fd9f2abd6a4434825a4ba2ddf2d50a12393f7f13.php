<div>
        <h1>Panel empresa</h1>
        <h3>Nombre</h3>
        <input type="text" wire:model="name">
        <h3>Description</h3>
        <input type="text" wire:model="name">
        <h3>Categorias</h3>
        <select wire:model="myCategories" multiple>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c); ?>"><?php echo e($c); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="button" wire:click="updateCategories">save categories</button>
        <h3>Tags</h3>
        <ul>
            <?php $__currentLoopData = $user["tags"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($t); ?> <button type="button" wire:click="removeTag(<?php echo e($loop->index); ?>)">Borrar</button> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <input type="text" wire:model="newTag">
        <button type="button" wire:click="addTag">add tag</button>
</div><?php /**PATH /home/shelby/Work/Demos/Mock/resources/views/livewire/user.blade.php ENDPATH**/ ?>