<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('licitaciones')->html();
} elseif ($_instance->childHasBeenRendered('OYfR9fi')) {
    $componentId = $_instance->getRenderedChildComponentId('OYfR9fi');
    $componentTag = $_instance->getRenderedChildComponentTagName('OYfR9fi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OYfR9fi');
} else {
    $response = \Livewire\Livewire::mount('licitaciones');
    $html = $response->html();
    $_instance->logRenderedChild('OYfR9fi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/erick/Escritorio/ModeloDeNegocios/localizador_inteligente_de_oportunidades_de_negocio_frontend/modeloDeNegocios/resources/views/licitaciones.blade.php ENDPATH**/ ?>