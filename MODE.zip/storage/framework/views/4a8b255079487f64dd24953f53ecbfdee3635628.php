<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('licitaciones-crear')->html();
} elseif ($_instance->childHasBeenRendered('T1kqnSK')) {
    $componentId = $_instance->getRenderedChildComponentId('T1kqnSK');
    $componentTag = $_instance->getRenderedChildComponentTagName('T1kqnSK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T1kqnSK');
} else {
    $response = \Livewire\Livewire::mount('licitaciones-crear');
    $html = $response->html();
    $_instance->logRenderedChild('T1kqnSK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shelby/Work/Demos/Mock/resources/views/licitaciones-crear.blade.php ENDPATH**/ ?>