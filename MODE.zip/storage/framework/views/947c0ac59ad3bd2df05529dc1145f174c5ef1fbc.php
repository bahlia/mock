<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user')->html();
} elseif ($_instance->childHasBeenRendered('2trCsfJ')) {
    $componentId = $_instance->getRenderedChildComponentId('2trCsfJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('2trCsfJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2trCsfJ');
} else {
    $response = \Livewire\Livewire::mount('user');
    $html = $response->html();
    $_instance->logRenderedChild('2trCsfJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shelby/Work/Demos/Mock/resources/views/panel.blade.php ENDPATH**/ ?>